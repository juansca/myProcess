# myProcess

Laboratorio para el entendimiento de los atributos y funcionalidades de procesos vistos como entidades en un sistema operativo.

En este laboratorio se evaluará la capacidad de generar las clases correspondientes
a un proceso de un sistema operativo. Dichos procesos cuentan con ciertos atributos
y métodos que se discutirán en clase y luego deberán ser implementados por el
estudiante.
